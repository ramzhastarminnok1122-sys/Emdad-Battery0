// ============================================================
//  پیامک خودکار به صاحب‌کار (کاوه‌نگار) — تابع سرور روی Vercel
//  راه‌اندازی:
//    1) ثبت‌نام در kavenegar.com و خرید پلن پیامک (۱۰۰ پیامک کافی است)
//    2) کپی API Key از پنل کاوه‌نگار
//    3) در Vercel ← پروژه ← Settings ← Environment Variables ← نام: SMS_API_KEY مقدار: کلید
//    4) از تب Deployments یک بار Redeploy
//    5) در پنل ادمین سایت ← تنظیمات ← شماره صاحب‌کار + روشن کردن پیامک
// ============================================================
module.exports = async function handler(req, res) {
  if (req.method !== 'POST') {
    res.status(405).json({ ok: false, error: 'POST only' });
    return;
  }
  try {
    const body = typeof req.body === 'string' ? JSON.parse(req.body || '{}') : (req.body || {});
    const to = body.to;
    const message = body.message;
    const key = process.env.SMS_API_KEY;
    if (!key) { res.status(500).json({ ok: false, error: 'SMS_API_KEY تنظیم نشده' }); return; }
    if (!to || !message) { res.status(400).json({ ok: false, error: 'to/message required' }); return; }

    const url = 'https://api.kavenegar.com/v1/' + encodeURIComponent(key) +
      '/sms/send.json?receptor=' + encodeURIComponent(to) +
      '&message=' + encodeURIComponent(message) +
      (process.env.SMS_SENDER ? '&sender=' + encodeURIComponent(process.env.SMS_SENDER) : '');

    const r = await fetch(url);
    const data = await r.json().catch(() => ({}));
    res.status(r.ok ? 200 : 502).json({ ok: r.ok, data });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
};
