import React, { useState } from 'react';
import { useNavigate, useSearchParams, Link } from 'react-router-dom';
import { useStore } from '../lib/store';
import { Btn, Icon, Field, PhoneInput } from '../components/ui';
import { cn, isMobile, normPhone, nameError, hashPw, uid } from '../lib/utils';

const CUST_KEY = 'chb_customer';

export default function Auth() {
  const { state, update, toast } = useStore();
  const nav = useNavigate();
  const [sp] = useSearchParams();
  const next = sp.get('next') || '/account';
  const [mode, setMode] = useState('login'); // login | register
  const [f, setF] = useState({ name: '', phone: '', pw: '', pw2: '' });
  const [err, setErr] = useState('');
  const [touched, setTouched] = useState(false);
  const [show, setShow] = useState(false);

  const set = (p) => setF((prev) => ({ ...prev, ...p }));

  const register = () => {
    setTouched(true);
    const e1 = nameError(f.name);
    if (e1) { setErr(e1); return; }
    const e2 = isMobile(f.phone) ? null : 'شماره موبایل معتبر (با پیش‌شماره اپراتورهای ایران) وارد کنید';
    if (e2) { setErr(e2); return; }
    if ((f.pw || '').length < 4) { setErr('رمز عبور حداقل ۴ کاراکتر باشد'); return; }
    if (f.pw !== f.pw2) { setErr('تکرار رمز عبور مطابقت ندارد'); return; }
    if ((state.users || []).some((u) => u.phone === normPhone(f.phone))) { setErr('این شماره قبلاً ثبت شده؛ وارد شوید.'); return; }
    setErr('');
    const u = { id: uid(), name: f.name.trim().replace(/\s+/g, ' '), phone: normPhone(f.phone), pw: hashPw(f.pw), verified: true, createdAt: Date.now(), blocked: false, bonusPoints: 0 };
    update((s) => ({ ...s, users: [...(s.users || []), u] }));
    localStorage.setItem(CUST_KEY, JSON.stringify({ id: u.id, name: u.name, phone: u.phone }));
    toast(`حساب شما ساخته شد؛ خوش آمدید ${u.name}! 🎉`);
    nav(next, { replace: true });
  };

  const login = () => {
    setTouched(true);
    const u = (state.users || []).find((x) => x.phone === normPhone(f.phone));
    if (!u) { setErr('حسابی با این شماره پیدا نشد؛ ثبت‌نام کنید.'); return; }
    if (u.blocked) { setErr('دسترسی این حساب توسط پشتیبانی محدود شده است. تماس بگیرید.'); return; }
    if (u.pw !== hashPw(f.pw)) { setErr('رمز عبور اشتباه است.'); return; }
    localStorage.setItem(CUST_KEY, JSON.stringify({ id: u.id, name: u.name, phone: u.phone }));
    toast(`خوش آمدید، ${u.name}!`);
    nav(next, { replace: true });
  };

  return (
    <div className="page auth-page">
      <div className="container" style={{ maxWidth: 520 }}>
        <div className="page-head" style={{ textAlign: 'center' }}>
          <span className="kicker">حساب کاربری امن</span>
          <h1>{mode === 'register' ? 'ساخت حساب جدید' : 'ورود به حساب'}</h1>
          <p style={{ marginInline: 'auto' }}>
            با حساب کاربری، درخواست امداد ثبت می‌کنید، ودیعه و فاکتورها را پرداخت می‌کنید و امتیاز باشگاه مشتریان می‌گیرید.
          </p>
        </div>

        <div className="wiz-card">
          <div className="tabs" style={{ marginBottom: 20 }}>
            <button className={cn('tab', mode === 'login' && 'active')} onClick={() => { setMode('login'); setErr(''); }}>ورود</button>
            <button className={cn('tab', mode === 'register' && 'active')} onClick={() => { setMode('register'); setErr(''); }}>ثبت‌نام سریع</button>
          </div>

          {mode === 'login' ? (
            <>
              <div className="form-grid" style={{ gridTemplateColumns: '1fr' }}>
                <Field label="شماره موبایل">
                  <PhoneInput value={f.phone} onChange={(v) => set({ phone: v })} />
                </Field>
                <Field label="رمز عبور">
                  <div className="phone-box">
                    <input className="input" type={show ? 'text' : 'password'} value={f.pw} onChange={(e) => set({ pw: e.target.value })} placeholder="••••" onKeyDown={(e) => e.key === 'Enter' && login()} />
                    <button type="button" className="phone-mark" style={{ background: 'none' }} onClick={() => setShow(!show)} aria-label="نمایش رمز">
                      <Icon name="eye" size={17} />
                    </button>
                  </div>
                </Field>
              </div>
              {err && <p className="field-error" style={{ marginTop: 8 }}><Icon name="alert" size={14} /> {err}</p>}
              <Btn variant="dark" icon="user" onClick={login} style={{ width: '100%', justifyContent: 'center', marginTop: 12 }}>ورود به حساب</Btn>
              <div className="note-box" style={{ marginTop: 14, fontSize: '.82rem' }}>
                <Icon name="shield" size={15} /> رمزتان را فراموش کرده‌اید؟ با شماره امداد تماس بگیرید تا پس از احراز هویت تلفنی، رمز جدید برایتان ثبت شود.
              </div>
            </>
          ) : (
            <>
              <div className="form-grid" style={{ gridTemplateColumns: '1fr' }}>
                <Field label="نام و نام خانوادگی" hint="همان نامی که روی فاکتور و گارانتی می‌خواهید">
                  <input className={cn('input', touched && nameError(f.name) && 'err')} value={f.name} onChange={(e) => set({ name: e.target.value })} placeholder="مثلاً: عبدالله زهی" />
                </Field>
                <Field label="شماره موبایل" hint="همین شماره شناسه حساب شماست — با دقت وارد کنید">
                  <PhoneInput value={f.phone} onChange={(v) => set({ phone: v })} />
                </Field>
                <div className="form-grid">
                  <Field label="رمز عبور"><input className="input" type="password" value={f.pw} onChange={(e) => set({ pw: e.target.value })} placeholder="حداقل ۴ کاراکتر" /></Field>
                  <Field label="تکرار رمز"><input className="input" type="password" value={f.pw2} onChange={(e) => set({ pw2: e.target.value })} placeholder="دوباره بنویسید" onKeyDown={(e) => e.key === 'Enter' && register()} /></Field>
                </div>
              </div>
              {err && <p className="field-error" style={{ marginTop: 8 }}><Icon name="alert" size={14} /> {err}</p>}
              <Btn variant="dark" icon="check" onClick={register} style={{ width: '100%', justifyContent: 'center', marginTop: 12 }}>ساخت حساب و ورود</Btn>
              <div className="note-box" style={{ marginTop: 14, fontSize: '.82rem' }}>
                <Icon name="info" size={15} /> حساب شما برای پیگیری درخواست‌ها، فاکتورها و امتیازهای باشگاه مشتریان استفاده می‌شود — بدون هزینه.
              </div>
            </>
          )}
        </div>
        <p style={{ textAlign: 'center', marginTop: 16, fontSize: '.85rem', color: 'var(--muted)' }}>
          <Link to="/" style={{ color: 'var(--brand)', fontWeight: 700 }}>← بازگشت به سایت</Link>
        </p>
      </div>
    </div>
  );
}
