import React, { useMemo, useState } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { useStore } from '../lib/store';
import { Btn, Icon, Field, Badge, Empty } from '../components/ui';
import { cn, toFa, fmtToman, normPhone, uid, compressImage } from '../lib/utils';
import { notifyOwner, fmMoney } from '../lib/notify';

export default function Pay() {
  const { state, update, toast } = useStore();
  const [sp] = useSearchParams();
  const order = (state.orders || []).find((o) => o.id === sp.get('order'));
  const req = (state.requests || []).find((r) => r.code === (sp.get('req') || '').toUpperCase());
  const kind = order ? 'order' : sp.get('kind') === 'deposit' && req ? 'deposit' : req ? 'service' : null;

  const [gotPic, setGotPic] = useState(false);
  const [receipt, setReceipt] = useState(null);
  const [busy, setBusy] = useState(false);

  const existing = useMemo(() => {
    if (order) return (state.payments || []).find((p) => p.kind === 'order' && p.refId === order.id);
    if (req) return (state.payments || []).find((p) => p.kind === kind && p.refId === req.code);
    return null;
  }, [state.payments, order, req, kind]);

  if (!kind) {
    return <div className="page"><div className="container"><Empty icon="banknote" title="صورتحسابی پیدا نشد" desc="از حساب کاربری یا صفحه پیگیری، موردنظر را انتخاب کنید."
      action={<Btn to="/account" variant="dark" icon="user">حساب کاربری من</Btn>} /></div></div>;
  }

  const card = state.settings.payCard || {};
  const dep = state.settings.deposit || { amount: 0 };
  const depApproved = req?.deposit?.status === 'approved' || (state.payments || []).some((p) => p.kind === 'deposit' && p.refId === req?.code && p.status === 'approved');

  let amount = 0, label = '', name = '', phone = '';
  if (kind === 'order') { amount = order.price; label = `سفارش باتری — ${order.batteryLabel}`; name = order.name; phone = order.phone; }
  if (kind === 'deposit') { amount = dep.amount || 0; label = `ودیعه حضور — ${req.code}`; name = req.name; phone = req.phone; }
  if (kind === 'service') {
    const raw = req?.report?.price ?? 0;
    amount = Math.max(0, raw - (depApproved ? (dep.amount || 0) : 0));
    label = `فاکتور امداد — ${req.code}`; name = req.name; phone = req.phone;
  }

  const upload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setBusy(true);
    try { setReceipt(await compressImage(file, 1100, 0.75)); }
    catch { toast('خواندن فایل ممکن نشد؛ عکس دیگری انتخاب کنید.', 'error'); }
    setBusy(false);
  };

  const submit = () => {
    if (!gotPic) { toast('قبل از پرداخت، حتماً از رسید عکس بگیرید و تیک آن را بزنید.', 'error'); return; }
    if (!receipt) { toast('عکس فیش واریز را آپلود کنید.', 'error'); return; }
    const pay = {
      id: uid(), kind, refId: order ? order.id : req.code, label,
      name, phone: normPhone(phone), amount, receipt,
      status: 'pending', at: Date.now(), note: ''
    };
    update((s) => {
      let next = { ...s, payments: [pay, ...(s.payments || [])] };
      if (kind === 'order') next.orders = s.orders.map((o) => o.id === order.id ? { ...o, status: 'در انتظار تایید پرداخت' } : o);
      if (kind === 'deposit') next.requests = s.requests.map((r) => r.code === req.code ? { ...r, deposit: { ...(r.deposit || {}), status: 'pending', paid: true } } : r);
      if (kind === 'service') next.requests = s.requests.map((r) => r.code === req.code ? { ...r, invoiceSubmitted: true } : r);
      return next;
    });
    toast(kind === 'deposit' ? 'فیش ودیعه ثبت شد؛ پس از تایید، امدادگر اعزام می‌شود.' : 'فیش شما ثبت شد؛ حداکثر تا چند دقیقه تایید می‌شود.');
    notifyOwner(state, {
      title: `🧾 فیش جدید (${kind === 'deposit' ? 'ودیعه' : kind === 'service' ? 'فاکتور امداد' : 'سفارش باتری'})`,
      body: `${name} — ${toFa(phone)}\nمبلغ: ${fmMoney(amount)} تومان\nبرای تایید، پنل صاحب‌کار را ببینید.`
    });
  };

  const kindChip = { order: '🛒 سفارش باتری', deposit: '🛡 ودیعه حضور', service: '⚡ فاکتور امداد' }[kind];

  return (
    <div className="page">
      <div className="container" style={{ maxWidth: 720 }}>
        <div className="page-head" style={{ textAlign: 'center' }}>
          <span className="kicker">{kindChip} — پرداخت امن با تایید انسانی</span>
          <h1>درگاه پرداخت</h1>
          <p style={{ marginInline: 'auto' }}>{label}</p>
        </div>

        {existing ? (
          <div className="wiz-card" style={{ textAlign: 'center' }}>
            <Badge tone={existing.status === 'approved' ? 'green' : existing.status === 'rejected' ? 'red' : 'amber'} dot>
              {existing.status === 'approved' ? 'تایید شد' : existing.status === 'rejected' ? 'رد شد' : 'در انتظار تایید'}
            </Badge>
            <h2 style={{ margin: '12px 0 6px' }}>
              {existing.status === 'approved' ? 'پرداخت شما تایید شد ✅' : existing.status === 'rejected' ? 'فیش تایید نشد' : 'فیش شما ثبت شد و در صف بررسی است'}
            </h2>
            <p style={{ color: 'var(--muted)', fontSize: '.92rem' }}>
              {existing.status === 'rejected'
                ? (existing.note ? `دلیل: ${existing.note} — ` : '') + 'لطفاً فیش واضح‌تری آپلود کنید یا با پشتیبانی تماس بگیرید.'
                : kind === 'deposit'
                  ? existing.status === 'approved' ? 'ودیعه شما تایید شد؛ امدادگر به‌زودی به‌سمت شما اعزام می‌شود.' : 'معمولاً بررسی چند دقیقه بیشتر طول نمی‌کشد.'
                  : existing.status === 'approved' ? 'از اعتماد شما سپاسگزاریم.' : 'معمولاً بررسی چند دقیقه بیشتر طول نمی‌کشد.'}
            </p>
            {existing.receipt && <img src={existing.receipt} alt="فیش واریز" style={{ maxHeight: 240, borderRadius: 14, margin: '14px auto' }} />}
            {existing.status === 'rejected' && (
              <Btn variant="red" icon="image" onClick={() => update((s) => ({
                ...s,
                payments: s.payments.filter((p) => p.id !== existing.id),
                orders: kind === 'order' ? s.orders.map((o) => o.id === order.id ? { ...o, status: 'در انتظار پرداخت' } : o) : s.orders,
                requests: kind === 'deposit' && req ? s.requests.map((r) => r.code === req.code ? { ...r, deposit: { ...(r.deposit || {}), status: 'pending' } } : r) : s.requests
              }))}>آپلود مجدد فیش</Btn>
            )}
            <div style={{ marginTop: 14, display: 'flex', gap: 14, justifyContent: 'center', flexWrap: 'wrap' }}>
              {req && <Link to={`/track/${req.code}`} className="card-link">بازگشت به پیگیری ←</Link>}
              <Link to="/account" className="card-link">حساب کاربری ←</Link>
            </div>
          </div>
        ) : (
          <>
            <div className="note-box" style={{ marginBottom: 18 }}>
              <Icon name="alert" size={18} />
              <span><b>نکته مهم:</b> قبل از واریز، حتماً از فیش یا رسید واریز <b>عکس بگیرید</b> — بعد از پرداخت باید همان‌جا آپلودش کنید تا پرداخت‌تان ثبت و تایید شود.</span>
            </div>

            {kind === 'deposit' && (
              <div className="note-box" style={{ marginBottom: 18, background: 'rgba(255,184,0,.1)', borderColor: 'rgba(255,184,0,.5)', color: '#7a5800' }}>
                <Icon name="shield" size={18} />
                <span><b>وديعه حضور چیست؟</b> {dep.note}</span>
              </div>
            )}

            <div className="grid-2">
              <div className="admin-panel">
                <h3 style={{ marginBottom: 12 }}><Icon name="banknote" size={18} /> کارت به کارت / ساتنا</h3>
                <div className="bank-card">
                  <div className="bank-card-top"><span>{card.bank}</span><Icon name="battery" size={22} /></div>
                  <div className="bank-num">{toFa(card.number)}</div>
                  <div className="bank-holder">{card.holder}</div>
                </div>
                <Btn variant="ghost" icon="copy" size="sm" style={{ marginTop: 12, width: '100%', justifyContent: 'center' }}
                  onClick={() => { navigator.clipboard?.writeText((card.number || '').replace(/\s/g, '')); toast('شماره کارت کپی شد'); }}>
                  کپی شماره کارت
                </Btn>
                <div className="summary-box" style={{ marginTop: 14 }}>
                  <div className="sum-row"><span>مبلغ قابل پرداخت</span><b style={{ color: 'var(--brand)', fontSize: '1.05rem' }}>{fmtToman(amount)}</b></div>
                  {kind === 'service' && depApproved && dep.amount > 0 && (
                    <div className="sum-row"><span>ودیعه پرداخت‌شده</span><b style={{ color: 'var(--green)' }}>− {fmtToman(dep.amount)}</b></div>
                  )}
                  <div className="sum-row"><span>پرداخت‌کننده</span><b>{name} — {toFa(phone)}</b></div>
                </div>
              </div>

              <div className="admin-panel">
                <h3 style={{ marginBottom: 12 }}><Icon name="image" size={18} /> آپلود فیش واریز</h3>
                <label className="switch" style={{ marginBottom: 14 }}>
                  <input type="checkbox" checked={gotPic} onChange={(e) => setGotPic(e.target.checked)} style={{ width: 18, height: 18, accentColor: 'var(--brand)' }} />
                  <span style={{ fontSize: '.9rem', fontWeight: 700 }}>از رسید/فیش واریز عکس گرفتم ✔</span>
                </label>
                <label className="upload-box" style={{ padding: 26 }}>
                  {receipt
                    ? <img src={receipt} alt="فیش" style={{ maxHeight: 170, margin: '0 auto 10px', borderRadius: 12 }} />
                    : <><Icon name="image" size={30} /><div style={{ marginTop: 6 }}>عکس فیش را اینجا انتخاب کنید</div><small>عکس واضح و خوانا باشد</small></>}
                  <input type="file" accept="image/*" style={{ display: 'none' }} onChange={upload} />
                </label>
                {busy && <p className="field-hint" style={{ marginTop: 8 }}>در حال پردازش تصویر…</p>}
                <Btn variant="primary" icon="check" onClick={submit} style={{ width: '100%', justifyContent: 'center', marginTop: 14 }} disabled={!gotPic || !receipt || busy}>
                  ثبت فیش و اتمام پرداخت
                </Btn>
                <p className="field-hint" style={{ marginTop: 10, textAlign: 'center' }}>فیش شما در حساب کاربری‌تان بایگانی و برای حسابداری ارسال می‌شود.</p>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
